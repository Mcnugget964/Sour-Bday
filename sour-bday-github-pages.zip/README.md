# sour-bday 🍋

A custom mobile-first Strands-style birthday puzzle.

## Puzzle

8 rows × 6 columns:

```text
M E S O R Y
T H M R E L
I N T U T T
A N U R S E
P F Y H V K
M R C L I N
O R E I L I
C A E W T H
```

The 7 answers are hidden from the player:
- THINK
- ARCHIVE
- COMPANY
- TRUTHS
- MEMORY
- FREE WILL
- LETSRUNIT (spangram)

The paths are a non-overlapping exact cover of the entire 48-letter grid. Every letter is used exactly once.

## What changed

- The player is NOT shown the word list.
- `LETSRUNIT` is the yellow spangram and can be solved at any point.
- All other solved words are blue.
- Letters stay white.
- Black background.
- A live white line follows the player's finger while dragging.
- Solved paths remain visible as blue/yellow lines.
- The opening title is `Do you want to play brain games tn?`
- Completion message is `Happy birthday Flora :)`.

## GitHub Pages

1. Create a GitHub repository named **`sour-bday`**.
2. Upload `index.html`, `style.css`, and `game.js` from this folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose `main` and `/ (root)`.
6. Save and wait for deployment.

If your GitHub username is `YOURUSERNAME`, the resulting address will be:

`https://YOURUSERNAME.github.io/sour-bday/`

GitHub Pages cannot choose an arbitrary URL slug independently of the repository name. The `sour-bday` part is the repository name; the username part comes from your GitHub account.

## Before giving Flora the QR code

Open the live URL on your phone and test:

- drag in every direction
- find `LETSRUNIT` first
- find the other six in different orders
- make sure all 48 letters become part of a solved path
- complete the puzzle and check the final message
- test the page in both Safari and Chrome mobile

## Editing

The puzzle data and paths are at the top of `game.js` under `GRID`, `WORDS`, and `VALID_PATHS`.

The visual colours are at the top of `style.css` under `:root`.
